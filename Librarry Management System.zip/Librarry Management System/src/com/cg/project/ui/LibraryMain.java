package com.cg.project.ui;

import java.util.Scanner;

import com.cg.bean.books.BooksBean;
import com.cg.bean.registration.BookRegistrationBean;
import com.cg.bean.transaction.TransactionBean;
import com.cg.bean.user.UserBean;
import com.cg.project.dao.LibraryDAOImpl;
import com.cg.project.dao.LibraryDao;
import com.cg.project.exception.LibraryException;
import com.cg.project.service.LibraryService;
import com.cg.project.service.LibraryServiceImpl;


public class LibraryMain {

	public static void main(String[] args) throws LibraryException {
		
		LibraryDao daoRef = new LibraryDAOImpl();
		LibraryService serRef = new LibraryServiceImpl();
		UserBean ub = new UserBean();
		BooksBean bb = new BooksBean();
		BookRegistrationBean br = new BookRegistrationBean();
		TransactionBean tb = new TransactionBean();
		
		
		Scanner sc = new Scanner(System.in);
		
		int userid = sc.nextInt();
		String password = sc.next();
		
		String var= daoRef.isValidLibrarian(userid, password);
		
		if(var=="y"||var=="Y"){
			
			System.out.println("Welcome Librarian....."+ub.getUserName());
			
		}
		
		else
		{
			System.out.println("Welcome Student..."+ub.getUserName());
		}

	}

}
