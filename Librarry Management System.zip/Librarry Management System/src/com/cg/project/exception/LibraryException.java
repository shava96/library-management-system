package com.cg.project.exception;

public class LibraryException extends Exception{
	
	public LibraryException() {
		super();
		
	}

	public LibraryException(String message, Throwable cause) {
		super(message, cause);
		
	}

}
