package com.cg.project.dao;

import com.cg.bean.books.BooksBean;
import com.cg.bean.registration.BookRegistrationBean;
import com.cg.bean.transaction.TransactionBean;
import com.cg.bean.user.UserBean;
import com.cg.project.exception.LibraryException;

public interface LibraryDao {

	//adding details......................
	public boolean  addUser(UserBean user) throws  LibraryException;
	public boolean addBooks(BooksBean abooks) throws  LibraryException;
	public BooksBean deleteBooks(int bookId) throws  LibraryException;
	public BooksBean issueBooks(int bookId) throws  LibraryException;
	public boolean transactions(BookRegistrationBean reg) throws  LibraryException;
	
	//displaying details......................
	
	public BooksBean getBooks() throws  LibraryException;
	
	public String isValidLibrarian(int userid,String password) throws LibraryException;
    
	
}
