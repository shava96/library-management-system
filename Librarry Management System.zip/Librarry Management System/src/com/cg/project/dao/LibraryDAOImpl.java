package com.cg.project.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.cg.bean.books.BooksBean;
import com.cg.bean.registration.BookRegistrationBean;
import com.cg.bean.transaction.TransactionBean;
import com.cg.bean.user.UserBean;
import com.cg.project.exception.LibraryException;
import com.cg.project.utils.DBUtils;

public class LibraryDAOImpl implements LibraryDao {

	private Connection dbConnection;

	{
		try {
			dbConnection = DBUtils.getConnection();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	
}

	
	//generating user id automatically......
	
	public int generateNextUserId() throws SQLException {
		int id = 0;

		String selectQuery = "select useridseq.nextval from dual";

		Statement selectStatement = dbConnection.createStatement();
		ResultSet result = selectStatement.executeQuery(selectQuery);

		result.next();

		id = result.getInt(1);
	
		
		return id;
	}
	
	
	// to add user..............
	
	@Override
	public boolean addUser(UserBean user) throws LibraryException {
		
		String insertQuery ="insert into usertable values(?,?,?,?,?) ";
		
		try {
			PreparedStatement insertStatement = dbConnection.prepareStatement(insertQuery);
			
			insertStatement.setInt(1, generateNextUserId());
			insertStatement.setString(2, user.getUserName());
			insertStatement.setString(3, user.getPassword());
			insertStatement.setString(4, user.getEmailId());
			insertStatement.setString(5, user.getLibrarian());
			
			int rows = insertStatement.executeUpdate();
			if(rows>0){
				System.out.println("New User Added..");
				//log.info("New User is Added");
				return true;
			}
			else 
				return false;
		} catch (SQLException e) {
			
			e.printStackTrace();
			//log.error(e.getMessage());
			return false;
		}
		
		
	}
	
	//generating book id automatically..

	public int generateNextBookId() throws SQLException {
		int id = 0;

		String selectQuery = "select bookidseq.nextval from dual";

		Statement selectStatement = dbConnection.createStatement();
		ResultSet result1 = selectStatement.executeQuery(selectQuery);

		result1.next();

		id = result1.getInt(1);
	
		
		return id;
	}

	
	
	//adding Books........
	
	@Override
	public boolean addBooks(BooksBean abooks) throws LibraryException {
		
		String insertQuery ="insert into bookinventory values(?,?,?,?,?,?) ";
		
		try {
			PreparedStatement insertStatement = dbConnection.prepareStatement(insertQuery);
			
			insertStatement.setInt(1, generateNextBookId());
			
			insertStatement.setString(2, abooks.getBookName());
			
			insertStatement.setString(3, abooks.getAuthor1());
			
			insertStatement.setString(4, abooks.getAuthor2());
			
			insertStatement.setString(5, abooks.getPublications());
			
			insertStatement.setString(6, abooks.getYearofpublication());
			
			int rows = insertStatement.executeUpdate();
			
			if(rows>0){
				System.out.println("New Book Added..");
				//log.info("New Book is Added");
				
			}
			return true;
				
		} catch (SQLException e) {
			
			e.printStackTrace();
			//log.error(e.getMessage());
			return false;
		}
		
	}

	
	
	//Deleting Books...

	@Override
	public BooksBean deleteBooks(int bookId) throws  LibraryException {
		
		String deleteQuery ="delete from bookinventory where book_id = ?";
		
		PreparedStatement deleteStatement;
		try {
			deleteStatement = dbConnection.prepareStatement(deleteQuery);
			
			deleteStatement.setInt(1, bookId);
			
			deleteStatement.executeQuery();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
	
		return null;
	}

	
	
	//Generating Registration Id Automatically......
	
	public int generateNextRegId() throws SQLException {
		int id = 0;

		String selectQuery = "select regidseq.nextval from dual";

		Statement selectStatement = dbConnection.createStatement();
		ResultSet result1 = selectStatement.executeQuery(selectQuery);

		result1.next();

		id = result1.getInt(1);
	
		
		return id;
	}
	
	//issue a book.......
	
	@Override
	public BooksBean issueBooks(int bookId) throws  LibraryException {
		
		//BooksBean book = new BooksBean();
		BookRegistrationBean br = new BookRegistrationBean();
		UserBean user = new UserBean();
        String insertQuery ="insert into bookreg values(?,?,?,?)";
		
		try {
			PreparedStatement insertStatement = dbConnection.prepareStatement(insertQuery);
			
			insertStatement.setInt(1, generateNextRegId());
			insertStatement.setInt(2, bookId);
			insertStatement.setInt(3, user.getUserId() );
			insertStatement.setDate(4, (Date) br.getRegistrationdate());
			insertStatement.setString(5, user.getLibrarian());
			
			insertStatement.executeUpdate();
			
		} catch (SQLException e) {
			
			e.printStackTrace();
			//log.error(e.getMessage());
			
		}
		
		return null;
	}
	
	//to generate transaction id..
	
	public int generateNextTransId() throws SQLException {
		int id = 0;

		String selectQuery = "select transidseq.nextval from dual";

		Statement selectStatement = dbConnection.createStatement();
		ResultSet result1 = selectStatement.executeQuery(selectQuery);

		result1.next();

		id = result1.getInt(1);
	
		
		return id;
	}
	
	
	
	
	
	//transaction.........

	@Override
	public boolean transactions(BookRegistrationBean reg) throws LibraryException {
		
     String insertQuery ="insert into bookreg values(?,?,sysdate,sysdate+14)";
		BookRegistrationBean br = new BookRegistrationBean();
		try {
			PreparedStatement insertStatement = dbConnection.prepareStatement(insertQuery);
			
			insertStatement.setInt(1, generateNextTransId());
			insertStatement.setInt(2, br.getRegistration_id());
			
              int rows = insertStatement.executeUpdate();
			
			if(rows>0){
				System.out.println("New transaction id  generated.");
				//log.info("New Book is Added");
				
			}
			
			
			return true;
			
			
		} catch (SQLException e) {
			
			e.printStackTrace();
			//log.error(e.getMessage());
			return false;
		}
	
		
	}
	
	
	
	//displaying all books.........

	@Override
	public void showBooks() throws LibraryException {
		
		
		
		String selectQuery = "select * from bookinventory";
		
		try {
			PreparedStatement selectStatement = dbConnection.prepareStatement(selectQuery);
			
            ResultSet result = selectStatement.executeQuery();
			
			while (result.next()) {
			
				int bid = result.getInt(1);
				String bname = result.getString(2);
				String a1 = result.getString(3);
				String a2 = result.getString(4);
				String pub = result.getString(5);
				String year = result.getString(6);
				
				BooksBean b = new BooksBean();
				
				b.setBookId(bid);
				b.setAuthor1(a1);
				b.setAuthor2(a2);
				b.setBookName(bname);
				b.setPublications(pub);
				b.setYearofpublication(year);
				
				System.out.println(bid +"   "+  bname+"   "+ a1+"   "+ a2+"   " + pub+"   "+year);
				
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
	}


	public UserBean getData(int userid) throws LibraryException{
		
		String  query = "Select * from usertable where user_id = ?";
		UserBean ub = new UserBean();
		
		try {
			PreparedStatement insertStatement = dbConnection.prepareStatement(query);
		    
			insertStatement.setInt(1, userid);
			
			
			ResultSet result = insertStatement.executeQuery();
			
			while(result.next()){
				
				
			int uid = result.getInt(1);
			String uname = result.getString(2);
			String userpass = result.getString(3);
			String mail = result.getString(4);
			String lib ="";
			lib=result.getString(5);
			
			ub.setUserId(uid);
			ub.setUserName(uname);
			ub.setPassword(userpass);
			ub.setEmailId(mail);
			ub.setLibrarian(lib);
			
			return ub;
			
			}
			
			
     	} catch (SQLException e) {
			
			e.printStackTrace();
			//LibraryException("");
			//log.error(e.getMessgae);
			 throw new LibraryException();
		}
	return ub;
}

public String isValidLibrarian(int userid,String password) throws LibraryException{
	
     	String  query = "Select * from usertable where user_id = ?";
     	UserBean ub = new UserBean();
     	String lib=""; 
     	
     	try {
			PreparedStatement insertStatement = dbConnection.prepareStatement(query);
		    
			insertStatement.setInt(1, userid);
			//insertStatement.setString(2, password);
			
			ResultSet result = insertStatement.executeQuery();
			
			
			while(result.next()){
			
			int uid = result.getInt(1);
			String uname = result.getString(2);
			String userpass = result.getString(3);
			String email = result.getString(4);
			lib=result.getString(5);
			
			ub.setUserId(uid);
			ub.setUserName(uname);
			ub.setEmailId(email);
			ub.setLibrarian(lib);
			if(userpass.equals(password)){
				
			System.out.println("Valid User...");
			//Log.info("Valid User..");
			
			
			return lib;
				
				
			}
			
			}
			
     	} catch (SQLException e) {
			
			e.printStackTrace();
			//LibraryException("");
			//log.error(e.getMessgae);
			throw new LibraryException("Login Failed..try again");
			
     	}
     	return lib;
}


}


