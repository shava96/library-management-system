package com.cg.project.exception;

public class LibraryException extends Exception{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -3792409052179991565L;
	public LibraryException() {
		super();
		
	}

	public LibraryException(String message, Throwable cause) {
		super(message, cause);
		
	}
	public LibraryException(String message) {
		super(message);
		
	}

}
