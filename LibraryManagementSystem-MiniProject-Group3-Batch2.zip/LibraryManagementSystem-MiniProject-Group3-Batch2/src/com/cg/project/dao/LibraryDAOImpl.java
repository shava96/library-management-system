package com.cg.project.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;

//import com.capgemini.utils.Log4jHTMLLayout;
import com.cg.bean.books.BooksBean;
import com.cg.bean.registration.BookRegistrationBean;
import com.cg.bean.transaction.TransactionBean;
import com.cg.bean.user.UserBean;
import com.cg.project.exception.LibraryException;
import com.cg.project.utils.DBUtils;

//import.com.cg.project.utils.Log4jHTMLLayout;
public class LibraryDAOImpl implements LibraryDao {

	
private static Logger log = Logger.getLogger(com.cg.project.utils.Log4jHTMLLayout.class);
	private Connection dbConnection;

	{
		try {
			dbConnection = DBUtils.getConnection();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	
}

	
	//generating user id automatically......
	
	public int generateNextUserId() throws SQLException {
		  int id = 0;

		String selectQuery = "select useridseq.nextval from dual";

		Statement selectStatement = dbConnection.createStatement();
		ResultSet result = selectStatement.executeQuery(selectQuery);

		result.next();

		id = result.getInt(1);
	
		
		return id;
	}
	
	
	// to add user..............
	
	@Override
	public boolean addUser(UserBean user) throws LibraryException {
		
		String insertQuery ="insert into usertable values(?,?,?,?,?) ";
		
		try {
			PreparedStatement insertStatement = dbConnection.prepareStatement(insertQuery);
			
			insertStatement.setInt(1, generateNextUserId());
			insertStatement.setString(2, user.getUserName());
			insertStatement.setString(3, user.getPassword());
			insertStatement.setString(4, user.getEmailId());
			insertStatement.setString(5, user.getLibrarian());
			
			int rows = insertStatement.executeUpdate();
			if(rows>0){
				System.out.println("New User Added..");
				log.info("New User is Added");
				return true;
			}
			
		} catch (SQLException e) {
			
			e.printStackTrace();
			log.error(e.getMessage());
			return false;
		}
		return false;
		
		
	}
	
	
	//delete a User..
	
	public boolean delUser(int uid) throws LibraryException {
		
    String deleteQuery ="delete from usertable where user_id = ? and (librarian='n' or librarian='N')";
		
		PreparedStatement deleteStatement;
		try {
			deleteStatement = dbConnection.prepareStatement(deleteQuery);
			
			deleteStatement.setInt(1, uid);
			//deleteStatement.setString(2, "n");
		
			deleteStatement.executeQuery();
			log.info("User Deleted");
			return true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		    throw new LibraryException("invalid user id ...please try again");
		}
		
		//return false;
	}
	
	
	
	
	
	
	//generating book id automatically..

	public int generateNextBookId() throws SQLException {
		int id = 0;

		String selectQuery = "select bookidseq.nextval from dual";

		Statement selectStatement = dbConnection.createStatement();
		ResultSet result1 = selectStatement.executeQuery(selectQuery);

		result1.next();

		id = result1.getInt(1);
	
		
		return id;
	}

	
	
	//adding Books........
	
	@Override
	public boolean addBooks(BooksBean abooks) throws LibraryException {
		
		String insertQuery ="insert into bookinventory values(?,?,?,?,?,?) ";
		
		try {
			PreparedStatement insertStatement = dbConnection.prepareStatement(insertQuery);
			
			insertStatement.setInt(1, generateNextBookId());
			
			insertStatement.setString(2, abooks.getBookName());
			
			insertStatement.setString(3, abooks.getAuthor1());
			
			insertStatement.setString(4, abooks.getAuthor2());
			
			insertStatement.setString(5, abooks.getPublications());
			
			insertStatement.setString(6, abooks.getYearofpublication());
			
			int rows = insertStatement.executeUpdate();
			
			if(rows>0){
				System.out.println("New Book Added..");
				log.info("New Book is Added");
				
			}
			return true;
				
		} catch (SQLException e) {
			
			e.printStackTrace();
			log.error(e.getMessage());
			return false;
		}
		
	}

	
	
	//Deleting Books...

	@Override
	public BooksBean deleteBooks(int bookId) throws  LibraryException {
		
		String deleteQuery ="delete from bookinventory where book_id = ?";
		
		try {

			PreparedStatement deleteStatement = dbConnection.prepareStatement(deleteQuery);
			
			deleteStatement.setInt(1, bookId);
			
			deleteStatement.executeQuery();
			log.info("Book is Deleted");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			log.error(e.getMessage());
			e.printStackTrace();
		}
		
		
		
		
	
		return null;
	}

	
	
	//Generating Registration Id Automatically......
	
	public int generateNextRegId() throws SQLException {
		int id = 0;

		String selectQuery = "select regidseq.nextval from dual";

		Statement selectStatement = dbConnection.createStatement();
		ResultSet result1 = selectStatement.executeQuery(selectQuery);

		result1.next();

		id = result1.getInt(1);
	
		
		return id;
	}
	
	
	
	
	//issue a book.......
	
	@Override
	public Boolean issueBooks(int bookId,int uid) throws  LibraryException {
		
		//BooksBean book = new BooksBean();
		//bookreg1istrationBean br = new bookreg1istrationBean();
		//UserBean user = new UserBean();
        String insertQuery ="insert into bookreg1 values(?,?,?,sysdate)";
		
		try {
			PreparedStatement insertStatement = dbConnection.prepareStatement(insertQuery);
			
			insertStatement.setInt(1, generateNextRegId());
			insertStatement.setInt(2, bookId);
			insertStatement.setInt(3, uid);
			//insertStatement.setDate(4, (Date) br.getRegistrationdate());
			
			insertStatement.executeUpdate();
			log.info("New book issued");
			return true;
			
		} catch (SQLException e) {
			
			e.printStackTrace();
			log.error(e.getMessage());
			throw new LibraryException("Book can't be issued due to some reason..");
		}
	}
	
	//to generate transaction id..
	
	public int generateNextTransId() throws SQLException {
		int id = 0;

		String selectQuery = "select transidseq.nextval from dual";

		Statement selectStatement = dbConnection.createStatement();
		ResultSet result1 = selectStatement.executeQuery(selectQuery);

		result1.next();

		id = result1.getInt(1);
	
		
		return id;
	}
	
	
	
	
	
	//transaction.........

	@Override
	public boolean transactions(int rid) throws LibraryException {
		
     String insertQuery ="insert into booktrans1 values(?,?,sysdate,sysdate+14,null)";
		@SuppressWarnings("unused")
		BookRegistrationBean br = new BookRegistrationBean();
		try {
			PreparedStatement insertStatement = dbConnection.prepareStatement(insertQuery);
			
			insertStatement.setInt(1, generateNextTransId());
			insertStatement.setInt(2, rid);
			
              int rows = insertStatement.executeUpdate();
			
			if(rows>0){
				System.out.println("New transaction is completed successfully.. ");
				log.info("New Book is Added into transactions ");
				
			}
			
			
			return true;
			
			
		} catch (SQLException e) {
			
			e.printStackTrace();
			log.error(e.getMessage());
			return false;
		}
	
		
	}
	
	
	//retrieving new user id..
	public int getnewuserid(String email) throws LibraryException{
	
		int uid=0;
		String  query = "Select user_id from usertable where email_id = ?";
		try {
			PreparedStatement insertStatement = dbConnection.prepareStatement(query);
		    
			insertStatement.setString(1, email);
			
			
			ResultSet result = insertStatement.executeQuery();
			
			while(result.next()){
				
			uid = result.getInt(1);
			
			return uid;
     	}
     	}catch(SQLException e){
     		e.printStackTrace();
     		//throw new LibraryException();
     		
     	}
		
		return uid;
	}
	
	//retrieving registration id.. by user id and book id...
	
	public int getRegId(int uid,int bookid) throws LibraryException{
		
		String  query = "Select registration_id from bookreg1 where user_id = ? and book_id=?";
     	//UserBean ub = new UserBean();
     	int rid=0;
     	
     	try {
			PreparedStatement insertStatement = dbConnection.prepareStatement(query);
		    
			insertStatement.setInt(1, uid);
			insertStatement.setInt(2, bookid);
			
			ResultSet result = insertStatement.executeQuery();
			
			while(result.next()){
				
			rid = result.getInt(1);
			
			return rid;
     	}
     	}catch(SQLException e){
     		e.printStackTrace();
     		//throw new LibraryException();
     		
     	}
		
		
		return rid;
		
	}
	
	
	
	
	
	//retrieving registration id..
	
	
	public int getRid(int uid) throws LibraryException{
		
		String  query = "Select registration_id from bookreg1 where user_id = ?";
     	//UserBean ub = new UserBean();
     	int rid=0;
     	
     	try {
			PreparedStatement insertStatement = dbConnection.prepareStatement(query);
		    
			insertStatement.setInt(1, uid);
			//insertStatement.setString(2, password);
			
			ResultSet result = insertStatement.executeQuery();
			
			while(result.next()){
				
			rid = result.getInt(1);
			
			return rid;
     	}
     	}catch(SQLException e){
     		e.printStackTrace();
     		//throw new LibraryException();
     		
     	}
		
		
		return rid;
	}
	
	
	//displaying all books.........

	@Override
	public void showBooks() throws LibraryException {
		
		
		
		String selectQuery = "select * from bookinventory";
		
		try {
			PreparedStatement selectStatement = dbConnection.prepareStatement(selectQuery);
			
            ResultSet result = selectStatement.executeQuery();
			
			while (result.next()) {
			
				int bid = result.getInt(1);
				String bname = result.getString(2);
				String a1 = result.getString(3);
				String a2 = result.getString(4);
				String pub = result.getString(5);
				String year = result.getString(6);
				
				BooksBean b = new BooksBean();
				
				b.setBookId(bid);
				b.setAuthor1(a1);
				b.setAuthor2(a2);
				b.setBookName(bname);
				b.setPublications(pub);
				b.setYearofpublication(year);
				
				System.out.println(bid +"		"+  bname+"		     "+ a1+"		     "+ a2+"		     " + pub+"	       	"+year);
				log.info("All Books are Displayed");
				
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
	}
	
	
	//view issued books...
	
public void showissuedBooks(int uid) throws LibraryException {
		
		
		
		String selectQuery = "select * from bookreg1 where user_id=?";
		
		try {
			PreparedStatement selectStatement = dbConnection.prepareStatement(selectQuery);
			
			selectStatement.setInt(1, uid);
			
            ResultSet result = selectStatement.executeQuery();
			
			while (result.next()) {
			
				int rid = result.getInt(1);
				int bid = result.getInt(2);
				
				Date regdate = result.getDate(4);
				 BookRegistrationBean br = new BookRegistrationBean();
				br.setBook_id(bid);
				br.setRegistration_id(rid);
				br.setRegistrationdate(regdate);	
				
				//System.out.println(rid +"			"+  bid+"			"+ regdate+"			"+ a2+"			" + pub+"			"+year);
				System.out.println("Registartion id: "+rid);
				System.out.println("Book id:         "+bid);
				System.out.println("Registration Date: "+regdate); 
				System.out.println();
				System.out.println();
				
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			throw new LibraryException("No data found..");
		}
		
		
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	//retrieve all user data from user table
	
	public UserBean getalluserdata(){
		
	UserBean ubb = new UserBean();
	
	return ubb;	
	}
	
	
	
	

	
	//Display all users..
	
public void showUsers() throws LibraryException {
		
		
		
		String selectQuery = "select * from usertable";
		
		try {
			PreparedStatement selectStatement = dbConnection.prepareStatement(selectQuery);
			
            ResultSet result = selectStatement.executeQuery();
			
			while (result.next()) {
			
				int uid = result.getInt(1);
				String uname = result.getString(2);
				
				String email = result.getString(4);
				String lib = result.getString(5);
				
				
				UserBean ub = new UserBean();
				
				ub.setUserId(uid);
				ub.setUserName(uname);
				ub.setEmailId(email);
				ub.setLibrarian(lib);
				
				
				System.out.println(uid +"   "+  uname+"   "+ email+"   "+ lib);
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new LibraryException("No users to display");
		}
		
		
		
	}
	
//Retrive all data from usertable per userid..
	

	public UserBean getData(int userid) throws LibraryException{
		
		String  query = "Select * from usertable where user_id = ?";
		UserBean ub = new UserBean();
		
		try {
			PreparedStatement insertStatement = dbConnection.prepareStatement(query);
		    
			insertStatement.setInt(1, userid);
			
			
			ResultSet result = insertStatement.executeQuery();
			
			while(result.next()){
				
				
			int uid = result.getInt(1);
			String uname = result.getString(2);
			String userpass = result.getString(3);
			String mail = result.getString(4);
			String lib ="";
			lib=result.getString(5);
			
			ub.setUserId(uid);
			ub.setUserName(uname);
			ub.setPassword(userpass);
			ub.setEmailId(mail);
			ub.setLibrarian(lib);
			
			return ub;
			
			}
			
			
     	} catch (SQLException e) {
			
			e.printStackTrace();
			//LibraryException("");
			//log.error(e.getMessgae);
			 throw new LibraryException();
		}
	return ub;
}

public String isValidLibrarian(int userid,String password) throws LibraryException{
	
     	String  query = "Select * from usertable where user_id = ?";
     	UserBean ub = new UserBean();
     	String lib=""; 
     	
     	try {
			PreparedStatement insertStatement = dbConnection.prepareStatement(query);
		    
			insertStatement.setInt(1, userid);
			//insertStatement.setString(2, password);
			
			ResultSet result = insertStatement.executeQuery();
			
			
			while(result.next()){
			
			int uid = result.getInt(1);
			String uname = result.getString(2);
			String userpass = result.getString(3);
			String email = result.getString(4);
			lib=result.getString(5);
			
			ub.setUserId(uid);
			ub.setUserName(uname);
			ub.setEmailId(email);
			ub.setLibrarian(lib);
			if(userpass.equals(password)){
				
			System.out.println("Valid User...");
			//Log.info("Valid User..");
			
			
			return lib;
				
				
			}
			
			}
			
     	} catch (SQLException e) {
			
			e.printStackTrace();
			//LibraryException("");
			//log.error(e.getMessgae);
			throw new LibraryException("Login Failed..try again");
			
     	}
     	return lib;
}


//Reterive all data from bookreg1istration table..per user id..

public BookRegistrationBean getRegData(int uid) {
	
	String  query = "Select * from bookreg1 where user_id = ?";
	//UserBean ub = new UserBean();
	BookRegistrationBean br = new BookRegistrationBean();
	try {
		PreparedStatement insertStatement = dbConnection.prepareStatement(query);
	    
		insertStatement.setInt(1, uid);
		
		
		ResultSet result = insertStatement.executeQuery();
		
		while(result.next()){
			
			
		int rid = result.getInt(1);
		int bookid=result.getInt(2);
		int userid=result.getInt(3);
		Date regdate=result.getDate(4);
		
		br.setRegistration_id(rid);
		br.setBook_id(bookid);
		br.setUser_id(userid);
		br.setRegistrationdate(regdate);
		
		return br;
		
		}
		
		
 	} catch (SQLException e) {
		
		e.printStackTrace();
		//LibraryException("");
		//log.error(e.getMessgae);
		// throw new LibraryException();
	}
	
	return br;
}


//Retrieve all data from bookreg1istration table..per registration id.

public TransactionBean getTransData(int rid) {
	
	String  query = "Select * from booktrans1 where registration_id = ?";
	//UserBean ub = new UserBean();
	TransactionBean tb = new TransactionBean();
	//bookreg1istrationBean br = new bookreg1istrationBean();
	try {
		PreparedStatement insertStatement = dbConnection.prepareStatement(query);
	    
		insertStatement.setInt(1, rid);
		
		
		ResultSet result = insertStatement.executeQuery();
		
		while(result.next()){
			
			
		int tid = result.getInt(1);
		int regid=result.getInt(2);
		Date idate=result.getDate(3);
		Date rdate=result.getDate(4);
		
		tb.setTransaction_id(tid);
		tb.setRegistration_id(regid);
		tb.setIssue_date(idate);
		tb.setReturn_date(rdate);
		
		
		
		return tb;
		
		}
		
		
 	} catch (SQLException e) {
		
		e.printStackTrace();
		//LibraryException("");
		//log.error(e.getMessgae);
		// throw new LibraryException();
	}
	
	
	return tb;
}


//reterive issued books (by passing user id in bookreg1 table, then reteriving book id from it then pass that into book inventory table).

public BooksBean getbook(int bid) throws LibraryException {
	
	BooksBean bb = new BooksBean();
	
	String selectQuery = "select * from bookinventory where book_id=?";
	
	try {
		PreparedStatement selectStatement = dbConnection.prepareStatement(selectQuery);
		
		selectStatement.setInt(1, bid);
        ResultSet result = selectStatement.executeQuery();
		
		while (result.next()) {
		
			int id = result.getInt(1);
			String bname = result.getString(2);
			String a1 = result.getString(3);
			String a2 = result.getString(4);
			String pub = result.getString(5);
			String year = result.getString(6);
			
			
			
			bb.setBookId(id);
			bb.setAuthor1(a1);
			bb.setAuthor2(a2);
			bb.setBookName(bname);
			bb.setPublications(pub);
			bb.setYearofpublication(year);
			
			return bb;			
		}
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		throw new LibraryException("Book Not Found...");
	}
	return bb;
	
}

//



//return a book (by deleting that issued book from book reg table..)

public boolean delissuedbook(int rid) throws LibraryException{

	String deleteQuery ="delete from bookreg1 where registration_id = ?";
	
	
	try {
		PreparedStatement deleteStatement = dbConnection.prepareStatement(deleteQuery);
		
		deleteStatement.setInt(1, rid);
		
		@SuppressWarnings("unused")
		ResultSet result=deleteStatement.executeQuery();
		
		return true;
	} catch (SQLException e) {
		e.printStackTrace();
		return false;//throw new LibraryException("Book cannot be deleted..");
	}
		
}




//calculate number of days..

public long days(int rid) throws LibraryException, ParseException{
	
	String selectQuery = "select * from booktrans1 where registration_id=?";
	
	try
	{
	PreparedStatement selectStatement = dbConnection.prepareStatement(selectQuery);
	selectStatement.setInt(1, rid);
	
	ResultSet result = selectStatement.executeQuery();
	
	while(result.next()){
		
		
		//String issueDate =  result.getString(3);
		//String actualrdate = result.getString(5);
		Date issueDate = result.getDate(3);
		Date actualrDate = result.getDate(5);
		//String actualrdate = result.getString(5);
		java.util.Date iDate = new java.util.Date(issueDate.getTime());
		java.util.Date aDate = new java.util.Date(actualrDate.getTime());
		@SuppressWarnings("unused")
		SimpleDateFormat sdf = new SimpleDateFormat("YYYY-MM-DD", Locale.ENGLISH);
		 //Date firstDate = (Date) sdf.parse(issueDate);
		   // Date secondDate = (Date)sdf.parse(actualrdate);
		    long diffInMillies = Math.abs(aDate.getTime() - iDate.getTime());
		    
		    long d = TimeUnit.DAYS.convert(diffInMillies, TimeUnit.MILLISECONDS);
		    return d;
	}
	}
	catch(SQLException e){
				e.printStackTrace();
				throw new LibraryException();

	}
	return 0;
}

////update actual return date.

public void updateActaulDate(int rid) throws LibraryException{
	String query="update booktrans1 set actual_return_date = sysdate where registration_id=?";
	
	try{
		PreparedStatement select = dbConnection.prepareStatement(query);
		select.setInt(1, rid);
		select.executeQuery();
		
	}catch(SQLException e){
		throw new LibraryException("Actual return date not updated..");
	}
}




//calculate fine...

public long fine(long totaldays) throws LibraryException{
	
	long fineperday=5;
	
	
	long f= fineperday*totaldays;
	
	return f;
}







}


