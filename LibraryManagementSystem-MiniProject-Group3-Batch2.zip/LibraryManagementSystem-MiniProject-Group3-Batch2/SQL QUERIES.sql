create table usertable (user_id Number(4) PRIMARY KEY , user_name varchar2(15), password varchar2(7), email_id varchar2(25), librarian VARCHAR2(1));

CREATE SEQUENCE useridseq
MINVALUE 1001
START WITH 1001
INCREMENT BY 1
NOCACHE;

create table bookinventory (book_id Number(4)  PRIMARY KEY, book_name varchar2(20), author1 varchar2(15),author2  varchar2(15), publisher varchar2(20), yearofpublication varchar2(4));

CREATE SEQUENCE bookidseq
MINVALUE 2001
START WITH 2001
INCREMENT BY 1
NOCACHE;

create table bookreg1 (registration_id Number(4)  PRIMARY KEY, book_id Number(4), user_id Number(4), registrationdate date);

CREATE SEQUENCE regidseq
MINVALUE 3001
START WITH 3001
INCREMENT BY 1
NOCACHE;

create table booktrans1 (transaction_id number(4)  PRIMARY KEY, registration_id number(4) , issue_date date , return_date date); 

alter table booktrans1 add Actual_return_Date date;

CREATE SEQUENCE transidseq
MINVALUE 4001
START WITH 4001
INCREMENT BY 1
NOCACHE;