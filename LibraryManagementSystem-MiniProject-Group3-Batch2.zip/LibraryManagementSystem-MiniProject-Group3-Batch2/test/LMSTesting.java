import static org.junit.Assert.*;

import java.util.Date;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.cg.bean.books.BooksBean;
import com.cg.bean.registration.BookRegistrationBean;
import com.cg.bean.transaction.TransactionBean;
import com.cg.bean.user.UserBean;
import com.cg.project.dao.LibraryDAOImpl;
import com.cg.project.dao.LibraryDao;
import com.cg.project.exception.LibraryException;

@SuppressWarnings("unused")
public class LMSTesting {
	private LibraryDao daoRef;
	
	LibraryDao daoref;
	@Before
	public void setup() {
		System.out.println("DAO instantiated");
		daoRef = new LibraryDAOImpl();
	}

	@After
	public void tearDown() {
		System.out.println("DAO cleaned");
		daoRef = null;
	}

	//ADDUSER
	
	@Test
	public void addUser() throws LibraryException {

		
		UserBean ub = new UserBean();
		ub.setLibrarian("y");
		ub.setPassword("123456");
		ub.setEmailId("cap@capgemini.com");
		ub.setUserName("User1");
		
		try{
			boolean ef = daoref.addUser(ub);
			Assert.assertTrue(ef);
			}catch(Exception e){
				e.printStackTrace();
				
				
			}
		
	}
	
	@Test
	public void addBooks() throws LibraryException{
		BooksBean bb = new BooksBean();
		bb.setBookName("harrypotter");
		bb.setAuthor1("JK");
		bb.setAuthor2("Rowling");
		bb.setPublications("sspub");
		bb.setYearofpublication("2015");
		
		boolean fl = daoRef.addBooks(bb);
		Assert.assertTrue(fl);
		
		
	}
	
	
	@Test
	public void issueABook() throws LibraryException{
		
		BookRegistrationBean br = new BookRegistrationBean();
		br.setBook_id(2011);
		br.setUser_id(1002);
		boolean ib = daoRef.issueBooks(br.getBook_id(), br.getUser_id());
		
	}
	
	@Test
	public void transactions() throws LibraryException{
		
		TransactionBean tb = new TransactionBean();
		BookRegistrationBean br = new BookRegistrationBean();
		tb.setRegistration_id(br.getRegistration_id());
		boolean trans = daoRef.transactions(tb.getRegistration_id());
				
		
	}
	
	@Test
	public void deleteIssueBooks() throws LibraryException{
		
		BookRegistrationBean br = new BookRegistrationBean();
		br.setRegistration_id(3011);
		boolean del = daoRef.delissuedbook(br.getRegistration_id());
	
	}

	
	
}